#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int parse_reg(char *s) {
    return atoi(s + 1);   // "R3" -> 3
}

int main() {
    FILE *in = fopen("program.asm", "r");
    FILE *out = fopen("init.mif", "w");

    if (!in || !out) return 1;

    fprintf(out,
        "DEPTH = 512;\n"
        "WIDTH = 16;\n"
        "ADDRESS_RADIX = DEC;\n"
        "DATA_RADIX = HEX;\n\n"
        "CONTENT\nBEGIN\n"
    );

    char line[128];
    int addr = 0;

    while (fgets(line, sizeof(line), in)) {
        char op[16], r1[16], r2[16], r3[16];
        int rd, rs1, rs2;
        unsigned short code = 0;

        int n = sscanf(line, "%s %[^,], %[^,], %s", op, r1, r2, r3);

        if (n >= 1) {
            if (strcmp(op, "IN") == 0) {
                sscanf(line, "%s %s", op, r1);
                rd = parse_reg(r1);
                code = (0x6 << 12) | (rd << 8);
            }
            else if (strcmp(op, "CALC") == 0) {
                if (n == 4) {
                    rd = parse_reg(r1);
                    rs1 = parse_reg(r2);
                    rs2 = parse_reg(r3);
                    code = (0xE << 12) | (rd << 8) | (rs1 << 4) | rs2;
                } else {
                    code = 0xE312; // fallback
                }
            }
            else if (strcmp(op, "STOP") == 0) {
                code = 0xF000;
            }
        }

        fprintf(out, "\t%d : %04X; -- %s", addr, code, line);
        addr++;
    }

    fprintf(out, "\t[%d..511] : 0000;\nEND;\n", addr);

    fclose(in);
    fclose(out);
    return 0;
}
